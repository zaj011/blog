This is an example site used for solely for testing purposes. **It is not meant to be used as a template for your site**. 

To create a new site, please use the starter template: [CaiJimmy/hugo-theme-stack-starter](https://github.com/CaiJimmy/hugo-theme-stack-starter/)